const $ = (id) => document.getElementById(id);
let socket = null;
let state = null;
let pendingWildIndex = null;
let toastTimer = null;

function showToast(message, isError = true) {
  const toast = $("toast");
  toast.textContent = message;
  toast.style.background = isError ? "#f0444e" : "#168a58";
  toast.classList.add("show");
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => toast.classList.remove("show"), 2800);
}

function send(payload) {
  if (!socket || socket.readyState !== WebSocket.OPEN) {
    showToast("Not connected to the game server.");
    return;
  }
  socket.send(JSON.stringify(payload));
}

function cardLabel(card) {
  if (card.value === "REVERSE") return "↔";
  if (card.value === "SKIP") return "⊘";
  if (card.value === "COLOR") return "✦";
  if (card.value === "+4") return "+4";
  return card.value;
}

function createCard(card, index = null, isHand = false) {
  const el = document.createElement("button");
  el.type = "button";
  el.className = `card card-front ${card.color}`;
  el.setAttribute("aria-label", `${card.color} ${card.value}`);
  const label = cardLabel(card);
  const inner = document.createElement("span");
  inner.className = "oval";
  const value = document.createElement("span");
  value.className = "value";
  value.textContent = label;
  if (label.length > 3) value.style.fontSize = "14px";
  if (label === "+4") value.classList.add("wild-four");
  inner.appendChild(value);
  const corner = document.createElement("span");
  corner.className = "corner";
  corner.textContent = label;
  const bottom = document.createElement("span");
  bottom.className = "corner bottom";
  bottom.textContent = label;
  el.append(inner, corner, bottom);
  if (isHand) {
    el.addEventListener("click", () => {
      if (!state || !state.started || state.finished) return;
      if (!isMyTurn()) {
        showToast("Wait for your turn.");
        return;
      }
      if (card.value === "COLOR" || card.value === "+4") {
        pendingWildIndex = index;
        $("colorModal").classList.remove("hidden");
      } else {
        send({type: "PLAY_CARD", index});
      }
    });
  } else {
    el.disabled = true;
  }
  return el;
}

function isMyTurn() {
  return state && state.current_player_id === state.you;
}

function render() {
  if (!state) return;
  $("joinScreen").classList.add("hidden");
  $("gameScreen").classList.remove("hidden");
  $("roomBadge").textContent = state.room;
  $("connectionLabel").textContent = "Connected";
  $("connectionLabel").style.color = "#62d99b";
  $("gameMessage").textContent = state.message || "";
  $("deckCount").textContent = `${state.deck_count} cards`;
  $("directionIcon").textContent = state.direction === 1 ? "↻" : "↺";
  $("penaltyPill").textContent = `+${state.pending_draw} PENALTY`;
  $("penaltyPill").classList.toggle("hidden", !state.pending_draw);

  const top = $("topCard");
  top.replaceChildren();
  if (state.top_card) top.appendChild(createCard(state.top_card));
  else {
    const waiting = document.createElement("div");
    waiting.className = "card-placeholder";
    waiting.textContent = "Waiting…";
    top.appendChild(waiting);
  }

  const opponents = $("opponents");
  opponents.replaceChildren();
  state.players.filter(p => !p.is_you).forEach(p => {
    const item = document.createElement("div");
    item.className = `opponent ${p.is_turn ? "active" : ""}`;
    const avatar = document.createElement("div");
    avatar.className = "avatar";
    avatar.textContent = p.name.slice(0, 1).toUpperCase();
    const meta = document.createElement("div");
    const name = document.createElement("div");
    name.className = "opponent-name";
    name.textContent = p.name;
    const count = document.createElement("div");
    count.className = "opponent-count";
    count.textContent = `${p.card_count} cards`;
    meta.append(name, count);
    item.append(avatar, meta);
    opponents.appendChild(item);
  });
  if (state.players.length === 1) {
    const waiting = document.createElement("div");
    waiting.className = "opponent";
    waiting.innerHTML = '<div class="avatar">+</div><div><div class="opponent-name">Waiting for friend</div><div class="opponent-count">Share the room code</div></div>';
    opponents.appendChild(waiting);
  }

  const hand = $("hand");
  hand.replaceChildren();
  state.hand.forEach((card, index) => hand.appendChild(createCard(card, index, true)));
  $("handCount").textContent = state.hand.length;

  const myTurn = isMyTurn();
  $("turnTitle").textContent = state.finished
    ? `${state.winner || "Someone"} wins!`
    : !state.started
      ? (state.players.length < 2 ? "Waiting for players" : "Ready to play")
      : myTurn ? "Your turn — make a move" : `${(state.players.find(p => p.id === state.current_player_id) || {}).name || "Opponent"}'s turn`;

  $("drawBtn").disabled = !state.started || state.finished || !myTurn;
  $("drawBtn").style.opacity = $("drawBtn").disabled ? ".45" : "1";
  $("startBtn").classList.toggle("hidden", state.started || !state.can_start);
  $("drawBtn").classList.toggle("hidden", !state.started || state.finished);
  $("actionHint").textContent = state.finished
    ? "Game over — start a new room for another round."
    : !state.started
      ? (state.can_start ? "Everyone is here? Start the game." : "Waiting for the host to start…")
      : myTurn
        ? (state.pending_draw ? `Play a legal stack or draw ${state.pending_draw} cards.` : "Play a matching card or draw one.")
        : "The table is waiting on another player.";
  $("unoBtn").disabled = !state.started || state.finished || state.hand.length !== 1;
  $("unoBtn").style.opacity = $("unoBtn").disabled ? ".45" : "1";
}

function connect(name, room) {
  const scheme = location.protocol === "https:" ? "wss:" : "ws:";
  socket = new WebSocket(`${scheme}//${location.host}/ws`);
  $("connectionLabel").textContent = "Connecting…";
  socket.addEventListener("open", () => {
    $("connectionLabel").textContent = "Joining room…";
    socket.send(JSON.stringify({type: "JOIN", name, room}));
  });
  socket.addEventListener("message", event => {
    let data;
    try { data = JSON.parse(event.data); } catch { return; }
    if (data.type === "ERROR") {
      showToast(data.message);
      return;
    }
    if (data.type === "STATE") {
      state = data;
      render();
    }
  });
  socket.addEventListener("close", () => {
    $("connectionLabel").textContent = "Disconnected";
    $("connectionLabel").style.color = "#f0444e";
    showToast("Connection closed. Refresh to reconnect.");
  });
  socket.addEventListener("error", () => showToast("Could not connect to the server."));
}

$("joinForm").addEventListener("submit", event => {
  event.preventDefault();
  const name = $("playerName").value.trim();
  const room = $("roomCode").value.trim().toUpperCase();
  if (!name) return showToast("Please enter a nickname.");
  connect(name, room);
});
$("startBtn").addEventListener("click", () => send({type: "START"}));
$("drawBtn").addEventListener("click", () => send({type: "DRAW"}));
$("drawPile").addEventListener("click", () => {
  if (state && state.started && isMyTurn()) send({type: "DRAW"});
});
$("unoBtn").addEventListener("click", () => send({type: "SAY_UNO"}));
$("copyRoomBtn").addEventListener("click", async () => {
  if (!state) return;
  try {
    await navigator.clipboard.writeText(state.room);
    showToast(`Room code ${state.room} copied!`, false);
  } catch {
    showToast(`Share this room code: ${state.room}`, false);
  }
});
document.querySelectorAll(".color-choice").forEach(button => {
  button.addEventListener("click", () => {
    if (pendingWildIndex === null) return;
    send({type: "PLAY_CARD", index: pendingWildIndex, color: button.dataset.color});
    pendingWildIndex = null;
    $("colorModal").classList.add("hidden");
  });
});
$("colorModal").addEventListener("click", event => {
  if (event.target.id === "colorModal") {
    pendingWildIndex = null;
    $("colorModal").classList.add("hidden");
  }
});
