import random
import string
import json
from typing import Optional
from fastapi import FastAPI, WebSocket, WebSocketDisconnect
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles

app = FastAPI(title="UNO Online")
app.mount("/static", StaticFiles(directory="static"), name="static")

COLORS = ["RED", "BLUE", "GREEN", "YELLOW"]
MAX_PLAYERS = 4
STARTING_HAND = 7


def make_deck():
    cards = []
    # Keep the card mix close to the user's terminal implementation:
    # two copies of number cards 1-9, plus action cards and wild cards.
    for color in COLORS:
        for number in range(1, 10):
            cards.extend([
                {"color": color, "value": str(number)},
                {"color": color, "value": str(number)},
            ])
        for value in ("+2", "SKIP", "REVERSE"):
            cards.append({"color": color, "value": value})
    cards.extend([{"color": "WILD", "value": "COLOR"} for _ in range(4)])
    cards.extend([{"color": "WILD", "value": "+4"} for _ in range(4)])
    random.shuffle(cards)
    return cards


def new_room_code():
    return "".join(random.choices(string.ascii_uppercase + string.digits, k=4))


class UnoRoom:
    def __init__(self, code: str):
        self.code = code
        self.players = []  # ordered list of {id, name, ws, hand}
        self.host_id = None
        self.started = False
        self.finished = False
        self.deck = []
        self.discard = []
        self.turn = 0
        self.direction = 1
        self.pending_draw = 0
        self.message = "Waiting for players to join."
        self.winner = None

    def player_by_id(self, player_id):
        return next((p for p in self.players if p["id"] == player_id), None)

    def current_player(self):
        if not self.players:
            return None
        return self.players[self.turn % len(self.players)]

    def draw_one(self):
        if not self.deck:
            if len(self.discard) <= 1:
                return None
            top = self.discard.pop()
            self.deck = self.discard
            self.discard = [top]
            random.shuffle(self.deck)
        return self.deck.pop()

    def start_game(self):
        if len(self.players) < 2:
            raise ValueError("At least 2 players are needed.")
        self.deck = make_deck()
        self.discard = []
        for player in self.players:
            player["hand"] = [self.draw_one() for _ in range(STARTING_HAND)]
        # Start with a numbered card to avoid opening action-card edge cases.
        first = None
        for i, card in enumerate(self.deck):
            if card["value"].isdigit():
                first = self.deck.pop(i)
                break
        if first is None:
            first = self.draw_one()
        self.discard.append(first)
        self.turn = 0
        self.direction = 1
        self.pending_draw = 0
        self.started = True
        self.finished = False
        self.winner = None
        self.message = f"{self.players[0]['name']} goes first."

    def playable(self, card):
        top = self.discard[-1]
        if self.pending_draw:
            if top["value"] == "+2":
                return card["value"] in ("+2", "+4")
            if top["value"] == "+4":
                return card["value"] == "+4"
            return False
        return (
            card["color"] == "WILD"
            or card["color"] == top["color"]
            or card["value"] == top["value"]
        )

    def advance(self, steps=1):
        self.turn = (self.turn + self.direction * steps) % len(self.players)

    def public_state(self, viewer_id):
        me = self.player_by_id(viewer_id)
        top = self.discard[-1] if self.discard else None
        return {
            "type": "STATE",
            "room": self.code,
            "started": self.started,
            "finished": self.finished,
            "winner": self.winner,
            "host_id": self.host_id,
            "you": viewer_id,
            "current_player_id": self.current_player()["id"] if self.started and self.players else None,
            "direction": self.direction,
            "pending_draw": self.pending_draw,
            "top_card": top,
            "deck_count": len(self.deck),
            "message": self.message,
            "players": [
                {
                    "id": p["id"],
                    "name": p["name"],
                    "card_count": len(p["hand"]),
                    "is_you": p["id"] == viewer_id,
                    "is_host": p["id"] == self.host_id,
                    "is_turn": bool(self.started and self.current_player() and p["id"] == self.current_player()["id"]),
                }
                for p in self.players
            ],
            "hand": me["hand"] if me else [],
            "can_start": bool(viewer_id == self.host_id and not self.started and len(self.players) >= 2),
        }


rooms = {}


async def send_state(room: UnoRoom):
    for p in list(room.players):
        try:
            await p["ws"].send_text(json.dumps(room.public_state(p["id"])))
        except Exception:
            pass


async def send_error(ws: WebSocket, message: str):
    await ws.send_text(json.dumps({"type": "ERROR", "message": message}))


def remove_player(room: UnoRoom, player_id: str):
    player = room.player_by_id(player_id)
    if player:
        room.players.remove(player)
    if not room.players:
        rooms.pop(room.code, None)
        return
    if room.host_id == player_id:
        room.host_id = room.players[0]["id"]
    if room.started and not room.finished:
        # Keep the current-turn index valid if someone leaves.
        room.turn = room.turn % len(room.players)
        if len(room.players) < 2:
            room.started = False
            room.finished = False
            room.message = "Not enough players remain. The game returned to the lobby."
        else:
            room.message = f"{player['name']} left the game."
    else:
        room.message = f"{player['name']} left the room."


@app.get("/")
async def home():
    return FileResponse("static/index.html")


@app.websocket("/ws")
async def websocket_endpoint(websocket: WebSocket):
    await websocket.accept()
    room = None
    player_id = None
    try:
        # The first client message must be JOIN.
        raw = await websocket.receive_text()
        data = json.loads(raw)
        if data.get("type") != "JOIN":
            await send_error(websocket, "First message must be JOIN.")
            await websocket.close()
            return

        name = str(data.get("name", "Player")).strip()[:18] or "Player"
        code = "".join(ch for ch in str(data.get("room", "")).upper() if ch.isalnum())[:8]
        if not code:
            code = new_room_code()
            while code in rooms:
                code = new_room_code()
        room = rooms.get(code)
        if room is None:
            room = UnoRoom(code)
            rooms[code] = room
        if room.started:
            await send_error(websocket, "This game has already started. Join another room.")
            await websocket.close()
            return
        if len(room.players) >= MAX_PLAYERS:
            await send_error(websocket, "This room is full (maximum 4 players).")
            await websocket.close()
            return

        player_id = "".join(random.choices(string.ascii_letters + string.digits, k=16))
        room.players.append({"id": player_id, "name": name, "ws": websocket, "hand": []})
        if room.host_id is None:
            room.host_id = player_id
            room.message = f"{name} created the room. Share code {code} with friends."
        else:
            room.message = f"{name} joined the room."
        await send_state(room)

        while True:
            raw = await websocket.receive_text()
            data = json.loads(raw)
            action = data.get("type")
            player = room.player_by_id(player_id)
            if player is None:
                break

            if action == "START":
                if player_id != room.host_id:
                    await send_error(websocket, "Only the room host can start the game.")
                elif room.started:
                    await send_error(websocket, "The game has already started.")
                elif len(room.players) < 2:
                    await send_error(websocket, "Invite at least one more player first.")
                else:
                    room.start_game()
                    await send_state(room)
                continue

            if action == "PLAY_CARD":
                if not room.started or room.finished:
                    await send_error(websocket, "The game is not currently running.")
                    continue
                if room.current_player()["id"] != player_id:
                    await send_error(websocket, "It's not your turn yet.")
                    continue
                try:
                    index = int(data.get("index", -1))
                except (TypeError, ValueError):
                    index = -1
                if index < 0 or index >= len(player["hand"]):
                    await send_error(websocket, "That card index is invalid.")
                    continue
                card = player["hand"][index]
                if not room.playable(card):
                    await send_error(websocket, "You can't play that card on the current top card.")
                    continue
                if card["value"] in ("COLOR", "+4"):
                    chosen = str(data.get("color", "")).upper()
                    if chosen not in COLORS:
                        await send_error(websocket, "Choose a color for your wild card.")
                        continue
                    card = dict(card)
                    card["color"] = chosen
                else:
                    card = dict(card)
                player["hand"].pop(index)
                room.discard.append(card)
                played_name = player["name"]

                if not player["hand"]:
                    room.finished = True
                    room.winner = player["name"]
                    room.message = f"🎉 {player['name']} wins!"
                    await send_state(room)
                    continue

                value = card["value"]
                if value == "REVERSE":
                    room.direction *= -1
                    room.message = f"{played_name} played Reverse. Direction changed."
                    if len(room.players) == 2:
                        room.advance(2)
                    else:
                        room.advance(1)
                elif value == "SKIP":
                    room.message = f"{played_name} skipped the next player."
                    room.advance(2)
                elif value == "+2":
                    room.pending_draw += 2
                    room.message = f"{played_name} played +2. Stack or draw {room.pending_draw} cards."
                    room.advance(1)
                elif value == "+4":
                    room.pending_draw += 4
                    room.message = f"{played_name} played +4 and chose {card['color']}. Stack or draw {room.pending_draw} cards."
                    room.advance(1)
                elif value == "COLOR":
                    room.message = f"{played_name} changed the color to {card['color']}."
                    room.advance(1)
                else:
                    room.message = f"{played_name} played {value}."
                    room.advance(1)
                await send_state(room)
                continue

            if action == "DRAW":
                if not room.started or room.finished:
                    await send_error(websocket, "The game is not currently running.")
                    continue
                if room.current_player()["id"] != player_id:
                    await send_error(websocket, "It's not your turn yet.")
                    continue
                if room.pending_draw:
                    amount = room.pending_draw
                    for _ in range(amount):
                        card = room.draw_one()
                        if card:
                            player["hand"].append(card)
                    room.pending_draw = 0
                    room.message = f"{player['name']} drew {amount} penalty cards and lost the turn."
                    room.advance(1)
                else:
                    card = room.draw_one()
                    if card:
                        player["hand"].append(card)
                    room.message = f"{player['name']} drew a card."
                    room.advance(1)
                await send_state(room)
                continue

            if action == "SAY_UNO":
                if len(player["hand"]) == 1:
                    room.message = f"{player['name']} says UNO!"
                    await send_state(room)
                continue

            await send_error(websocket, "Unknown action.")
    except WebSocketDisconnect:
        pass
    except Exception as exc:
        try:
            await send_error(websocket, f"Server error: {str(exc)}")
        except Exception:
            pass
    finally:
        if room is not None and player_id is not None:
            name = room.player_by_id(player_id)
            remove_player(room, player_id)
            if room.code in rooms:
                await send_state(room)
